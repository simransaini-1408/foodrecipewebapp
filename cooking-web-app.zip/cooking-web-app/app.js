const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const fileUpload = require('express-fileupload');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const flash = require('connect-flash');



//initialising a new express appliation
const app = express();
const port = process.env.PORT || 3000; //setting a port umber or environment pport number

//database details
require('dotenv').config();

//now adding couple of middlewaes 

app.use(express.urlencoded({extended: true}));
app.use(express.static('public'));//everithing we require something like images we dont need to list all path but just want to put /inmg folder and that why we create a public folder which will crate it
//(ii) middleware
app.use(expressLayouts);

app.use(cookieParser('CookingBlogSecure'));
app.use(session({
  secret: 'CookingBlogSecretSession',
  saveUninitialized: true,
  resave: true
}));
app.use(flash());
app.use(fileUpload());




app.set('layout','./layouts/main'); 
app.set('view engine','ejs'); 
 
//route

const routes = require('./server/routes/recipeRoutes.js')
app.use('/',routes);

//all thibgs listen on this port number
app.listen(port,()=> console.log(`Listening to port ${port}`));
 //creating all the files that we needn